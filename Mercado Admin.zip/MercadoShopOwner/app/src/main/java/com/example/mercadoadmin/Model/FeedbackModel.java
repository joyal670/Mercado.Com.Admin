package com.example.mercadoadmin.Model;

public class FeedbackModel {

    private String feeback;

    public FeedbackModel()
    {
    }

    public FeedbackModel(String feeback) {
        this.feeback = feeback;
    }

    public String getFeeback() {
        return feeback;
    }

    public void setFeeback(String feeback) {
        this.feeback = feeback;
    }

}
