package com.example.mercadoadmin.Activity;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentResolver;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.mercadoadmin.Model.ShopModel;
import com.example.mercadoadmin.R;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

public class ShopDetails_Activity extends AppCompatActivity {

    private static int image_pic_request = 1;
    private Uri mImageUri;
    private Button mUploadbtn;
    private TextView showUpload;
    private EditText etFilename;
    private EditText etPlace;
    private EditText etPhone;
    private Spinner etType;
    private ImageView mImageView;
    private ProgressBar mProgressBar;

    private DatabaseReference mdatabaseReference;
    private StorageReference mstorageReference;
    private FirebaseUser firebaseUser;
    private FirebaseAuth firebaseAuth;

    private StorageTask mUploadTask;
    SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shopdetails);

        try {
            mUploadbtn = findViewById(R.id.btnUpload);
            showUpload = findViewById(R.id.showuploads);
            etFilename = findViewById(R.id.etFileName);
            mImageView = findViewById(R.id.imageView);
            mProgressBar = findViewById(R.id.progressbar);
            etPhone = findViewById(R.id.etPhone);
            etPlace = findViewById(R.id.etPlace);
            etType = findViewById(R.id.etType);

            String[] catogries = {"Supermarket", "Provisionshop", "Stationaryshop", "Fishmarket", "Butchershop", "Vegetableshop", "Medicalshop", "Electronicshop", "Fashion"};
            ArrayAdapter<String> catog = new ArrayAdapter<String>(ShopDetails_Activity.this, android.R.layout.simple_spinner_dropdown_item, catogries);
            etType.setAdapter(catog);

            firebaseAuth = FirebaseAuth.getInstance();
            firebaseUser = firebaseAuth.getCurrentUser();

            sharedPreferences = getSharedPreferences("data", 0);
            String a1 = sharedPreferences.getString("userid", "");

            mdatabaseReference = FirebaseDatabase.getInstance().getReference("shop_owner").child(a1).child("shop_details");
            mstorageReference = FirebaseStorage.getInstance().getReference("shop_owner/shop_image");

            mUploadbtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (mUploadTask != null && mUploadTask.isInProgress()) {
                        Toast.makeText(ShopDetails_Activity.this, "Uploading in Progress", Toast.LENGTH_SHORT).show();
                    } else {
                        uploadFile();
                    }
                }
            });

            mImageView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    openFileChooser();
                }
            });

//        showUpload.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent intent = new Intent(MainActivity.this, ImageActivity.class);
//                startActivity(intent);
//            }
//        });

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private String getFileExtention(Uri uri)
    {
        ContentResolver cr = getContentResolver();
        MimeTypeMap mime = MimeTypeMap.getSingleton();
        return mime.getExtensionFromMimeType(cr.getType(uri));
    }

    private void uploadFile() {
        try {

            if (mImageUri != null) {
                StorageReference fileRef = mstorageReference.child(System.currentTimeMillis() + "." + getFileExtention(mImageUri));
                mUploadTask = fileRef.putFile(mImageUri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                        Handler handler = new Handler();
                        handler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                mProgressBar.setProgress(0);
                            }
                        }, 500);

                        Task<Uri> uriTask = taskSnapshot.getStorage().getDownloadUrl();
                        while (!uriTask.isSuccessful()) ;
                        Uri downloadUrl = uriTask.getResult();

                        sharedPreferences = getSharedPreferences("data", 0);
                        String a1 = sharedPreferences.getString("userid", "");

                        ShopModel shopModel = new ShopModel(etFilename.getText().toString().trim(), downloadUrl.toString(), etPlace.getText().toString(), etPhone.getText().toString(), etType.getSelectedItem().toString(), a1);
                        Toast.makeText(ShopDetails_Activity.this, "Success", Toast.LENGTH_SHORT).show();

                        String uploadId = mdatabaseReference.push().getKey();
                        mdatabaseReference.child(uploadId).setValue(shopModel);

                        Toast.makeText(ShopDetails_Activity.this, uploadId, Toast.LENGTH_LONG).show();

                        Intent intent = new Intent(ShopDetails_Activity.this, HomeScreen_Activity.class);
                        startActivity(intent);

                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(ShopDetails_Activity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }).addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onProgress(@NonNull UploadTask.TaskSnapshot taskSnapshot) {
                        double progress = (100.0 * taskSnapshot.getBytesTransferred() / taskSnapshot.getTotalByteCount());
                        mProgressBar.setProgress((int) progress);
                    }
                });
            } else {
                Toast.makeText(this, "No file Selected", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void openFileChooser() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(intent, image_pic_request);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        try {
            if (requestCode == image_pic_request && resultCode == RESULT_OK && data != null && data.getData() != null) {
                mImageUri = data.getData();
                Picasso.get().load(mImageUri).into(mImageView);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
