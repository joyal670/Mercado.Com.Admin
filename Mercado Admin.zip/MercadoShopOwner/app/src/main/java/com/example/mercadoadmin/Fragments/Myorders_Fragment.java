package com.example.mercadoadmin.Fragments;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.example.mercadoadmin.Activity.DeliveryBoySelection_Activity;
import com.example.mercadoadmin.Activity.ViewShopDetails_Activity;
import com.example.mercadoadmin.Model.OrderModel;
import com.example.mercadoadmin.R;
import com.example.mercadoadmin.adapter.OrderDataAdapter;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 */
public class Myorders_Fragment extends Fragment {

    DatabaseReference databaseReference;
    ListView orderrecyclerview;
    SharedPreferences sharedPreferences;
    List<OrderModel> mOrderModel;
    OrderDataAdapter mOrderDataAdapter;

    public Myorders_Fragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(final LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        final View view = inflater.inflate(R.layout.fragment_myorders, container, false);

        try {

            sharedPreferences = this.getActivity().getSharedPreferences("data", 0);
            final String a1 = sharedPreferences.getString("userid", "");

            orderrecyclerview = view.findViewById(R.id.orderrecyclerview);

            databaseReference = FirebaseDatabase.getInstance().getReference("order_data");
            databaseReference.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    mOrderModel.clear();
                    for (DataSnapshot dataSnapshot1 : dataSnapshot.getChildren()) {
                        if (a1.equals(dataSnapshot1.child("shopownerId").getValue().toString())) {
                            OrderModel upload = dataSnapshot1.getValue(OrderModel.class);
                            mOrderModel.add(upload);
                        }
                    }
                    mOrderDataAdapter.notifyDataSetChanged();
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    Toast.makeText(getContext(), databaseError.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });

            mOrderModel = new ArrayList<>();
            mOrderDataAdapter = new OrderDataAdapter(getContext(), mOrderModel);
            orderrecyclerview.setAdapter(mOrderDataAdapter);
            orderrecyclerview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    Intent intent = new Intent(getContext(), DeliveryBoySelection_Activity.class);
                    intent.putExtra("chkImageUrl", mOrderModel.get(position).getProductImageUrl());
                    intent.putExtra("chkName", mOrderModel.get(position).getProductName());
                    intent.putExtra("chkDescription", mOrderModel.get(position).getProductDescription());
                    intent.putExtra("chkPrice", mOrderModel.get(position).getProductPrice());
                    intent.putExtra("chkType", mOrderModel.get(position).getProductType());
                    intent.putExtra("chkStoke", mOrderModel.get(position).getProductStoke());
                    intent.putExtra("chkpUserkey", mOrderModel.get(position).getShopownerId());
                    intent.putExtra("chkmKey", mOrderModel.get(position).getProductId());
                    intent.putExtra("UserKey", mOrderModel.get(position).getUserId());
                    intent.putExtra("chkqty", mOrderModel.get(position).getProductQty());

                    intent.putExtra("house", mOrderModel.get(position).getHouse());
                    intent.putExtra("area", mOrderModel.get(position).getArea());
                    intent.putExtra("city", mOrderModel.get(position).getCity());
                    intent.putExtra("district", mOrderModel.get(position).getDistrict());
                    intent.putExtra("pincode", mOrderModel.get(position).getPincode());
                    intent.putExtra("contName", mOrderModel.get(position).getContName());
                    intent.putExtra("contNumber", mOrderModel.get(position).getContNumber());
                    intent.putExtra("contAltNumber", mOrderModel.get(position).getContAltNumber());
                    intent.putExtra("totalPrice", mOrderModel.get(position).getTotalPrice());
                    intent.putExtra("status", mOrderModel.get(position).getStatus());
                    intent.putExtra("orderId", mOrderModel.get(position).getOrderId());


                    startActivity(intent);

                }
            });

        } catch (Exception e) {
            e.printStackTrace();
        }
        return view;
    }


}
