package com.example.mercadoadmin.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Toast;

import com.example.mercadoadmin.Model.ProductModel;
import com.example.mercadoadmin.R;
import com.example.mercadoadmin.adapter.ProductAdapter;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;
import java.util.List;

public class ViewProduct_Activity extends AppCompatActivity implements ProductAdapter.OnitemClickListener{

    RecyclerView viewproductrecycler;
    ProductAdapter productAdapter;
    DatabaseReference databaseReference;
    List<ProductModel> mProductmodel;
    private FirebaseStorage firebaseStorage;
    private ValueEventListener mDBListener;
    SharedPreferences sharedPreferences;
    String a1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_product);

        try {

            viewproductrecycler = findViewById(R.id.viewproductrecycler);
            viewproductrecycler.setLayoutManager(new LinearLayoutManager(this));
            viewproductrecycler.setHasFixedSize(true);
            firebaseStorage = FirebaseStorage.getInstance();

//        databaseReference = FirebaseDatabase.getInstance().getReference("shop_owner").child("product");

            sharedPreferences = getSharedPreferences("data", 0);
            a1 = sharedPreferences.getString("userid", "");

            Query query = FirebaseDatabase.getInstance().getReference("shop_owner").child(a1).child("product")
                    .orderByChild("pUserKey").equalTo(a1);

            query.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    mProductmodel.clear();
                    for (DataSnapshot dataSnapshot1 : dataSnapshot.getChildren()) {
                        ProductModel upload = dataSnapshot1.getValue(ProductModel.class);
                        upload.setmKey(dataSnapshot1.getKey());
                        mProductmodel.add(upload);
                    }
                    productAdapter.notifyDataSetChanged();
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    Toast.makeText(ViewProduct_Activity.this, databaseError.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });

            mProductmodel = new ArrayList<>();
            productAdapter = new ProductAdapter(ViewProduct_Activity.this, mProductmodel);
            viewproductrecycler.setAdapter(productAdapter);
            productAdapter.setOnClickListener(ViewProduct_Activity.this);


//        mDBListener = databaseReference.addValueEventListener(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
//                mProductmodel.clear();
//                for(DataSnapshot dataSnapshot1 : dataSnapshot.getChildren())
//                {
//                    ProductModel upload = dataSnapshot1.getValue(ProductModel.class);
//                    upload.setmKey(dataSnapshot1.getKey());
//                    mProductmodel.add(upload);
//                }
//                productAdapter.notifyDataSetChanged();
//            }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError databaseError) {
//                Toast.makeText(ViewProduct_Activity.this, databaseError.getMessage(), Toast.LENGTH_SHORT).show();
//            }
//        });

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onItemClick(int position)
    {
        try {
            String stoke = mProductmodel.get(position).getpStoke();
            final String productId = mProductmodel.get(position).getmKey();

            String[] items = {"Out of Stoke", "In Stoke"};
            AlertDialog.Builder dialog = new AlertDialog.Builder(ViewProduct_Activity.this);
            dialog.setTitle("Select Options");
            dialog.setItems(items, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    if (which == 0) {
                        final DatabaseReference reference = FirebaseDatabase.getInstance().getReference("shop_owner").child(a1).child("product").child(productId);
                        reference.child("pStoke").setValue("Out of Stoke");
                    }
                    if (which == 1) {
                        final DatabaseReference reference = FirebaseDatabase.getInstance().getReference("shop_owner").child(a1).child("product").child(productId);
                        reference.child("pStoke").setValue("In Stoke");
                    }
                }
            });
            dialog.create().show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try {
            databaseReference.removeEventListener(mDBListener);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
