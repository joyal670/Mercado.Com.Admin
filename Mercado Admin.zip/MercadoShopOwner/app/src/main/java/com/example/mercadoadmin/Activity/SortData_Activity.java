package com.example.mercadoadmin.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.mercadoadmin.Model.OrderModel;
import com.example.mercadoadmin.R;
import com.example.mercadoadmin.adapter.StatisticsAdapter;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class SortData_Activity extends AppCompatActivity {


    ListView datelistview;
    SharedPreferences sharedPreferences;
    List<OrderModel> mOrderModel;
    DatabaseReference databaseReference;
    StatisticsAdapter mStatisticsAdapter;
    String a1;

    int total = 0;
    TextView totalorders, totalprice;
    int count = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sort_data);

        try {

            datelistview = findViewById(R.id.datelistview);
            totalorders = findViewById(R.id.totalorders2);
            totalprice = findViewById(R.id.totalprice2);

            final String test = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
            final String temp = "2018-12-12";


            sharedPreferences = getSharedPreferences("data", 0);
            a1 = sharedPreferences.getString("userid", "");


            databaseReference = FirebaseDatabase.getInstance().getReference("order_data");
//        databaseReference.orderByChild("orderDate").startAt("2017-02-12");
            databaseReference.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    mOrderModel.clear();
                    for (DataSnapshot dataSnapshot1 : dataSnapshot.getChildren()) {
                        if (a1.equals(dataSnapshot1.child("shopownerId").getValue().toString())) {
                            if (test.equals(dataSnapshot1.child("orderDate").getValue().toString())) {
                                OrderModel upload = dataSnapshot1.getValue(OrderModel.class);

                                try {

                                    int qty = 0;
                                    int price = 0;

                                    qty = qty + Integer.parseInt(dataSnapshot1.child("productQty").getValue().toString());
                                    price = price + Integer.parseInt(dataSnapshot1.child("productPrice").getValue().toString());
                                    int temp = qty * price;
                                    total = total + temp;
                                    totalprice.setText(total + "");

                                    count = count + 1;
                                    totalorders.setText(count + "");
                                } catch (NumberFormatException e) {
                                    e.printStackTrace();
                                }
                                mOrderModel.add(upload);
                            }
                        }
                    }
                    mStatisticsAdapter.notifyDataSetChanged();
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    Toast.makeText(SortData_Activity.this, databaseError.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });

            mOrderModel = new ArrayList<>();
            mStatisticsAdapter = new StatisticsAdapter(SortData_Activity.this, mOrderModel);
            datelistview.setAdapter(mStatisticsAdapter);


        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void showAlert()
    {
        LayoutInflater li = LayoutInflater.from(SortData_Activity.this);
        View date = li.inflate(R.layout.showdate_prompt,null);
        AlertDialog.Builder alertBuilder = new AlertDialog.Builder(SortData_Activity.this);
        alertBuilder.setView(date);

        final DatePicker datepicker;

        datepicker = date.findViewById(R.id.datepicker);


        final AlertDialog alertDialog = alertBuilder.create();

        Calendar calendar = Calendar.getInstance();
        datepicker.init(calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH), new DatePicker.OnDateChangedListener() {
            @Override
            public void onDateChanged(DatePicker view, int year, int monthOfYear, int dayOfMonth)
            {
               final String mydate = datepicker.getYear() + "-" + "0"+ datepicker.getMonth() + "-" + datepicker.getDayOfMonth()  ;
                alertDialog.dismiss();




            }
        });
        alertDialog.show();

    }
}
