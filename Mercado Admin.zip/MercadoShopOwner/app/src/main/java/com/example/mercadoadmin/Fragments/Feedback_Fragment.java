package com.example.mercadoadmin.Fragments;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.mercadoadmin.Activity.HomeScreen_Activity;
import com.example.mercadoadmin.Model.FeedbackModel;
import com.example.mercadoadmin.R;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

/**
 * A simple {@link Fragment} subclass.
 */
public class Feedback_Fragment extends Fragment {

    EditText userfeedback;
    Button userfeedbackbtn;
    SharedPreferences sharedPreferences;
    DatabaseReference databaseReference;

    public Feedback_Fragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_feedback, container, false);

        userfeedback = view.findViewById(R.id.userfeedback);
        userfeedbackbtn = view.findViewById(R.id.userfeedbackbtn);

        userfeedbackbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                feedback();
            }
        });

        return view;
    }

    private void feedback() {

        try {
            sharedPreferences = this.getActivity().getSharedPreferences("data", 0);
            final String a1 = sharedPreferences.getString("userid", "");

            databaseReference = FirebaseDatabase.getInstance().getReference("user_feedback").child("shop_owner").child(a1);

            String pushkey = databaseReference.push().getKey();

            FeedbackModel model = new FeedbackModel(userfeedback.getText().toString());
            databaseReference.child(pushkey).setValue(model);
            Toast.makeText(getContext(), "Thank You", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(getContext(), HomeScreen_Activity.class);
            startActivity(intent);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
