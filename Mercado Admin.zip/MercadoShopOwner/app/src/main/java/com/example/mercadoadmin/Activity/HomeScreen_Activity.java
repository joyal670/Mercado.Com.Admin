package com.example.mercadoadmin.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.RecyclerView;

import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.mercadoadmin.Fragments.Feedback_Fragment;
import com.example.mercadoadmin.Fragments.Home_Fragment;
import com.example.mercadoadmin.Fragments.Logout_Fragment;
import com.example.mercadoadmin.Fragments.Myorders_Fragment;
import com.example.mercadoadmin.Fragments.Statistics_Fragment;
import com.example.mercadoadmin.Fragments.Settings_Fragment;
import com.example.mercadoadmin.Model.ShopModel;
import com.example.mercadoadmin.R;
import com.example.mercadoadmin.adapter.ImageAdapter;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;

import java.util.List;

public class HomeScreen_Activity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    DrawerLayout mDrawerLayout;
    ActionBarDrawerToggle mDrawerToogle;
    TextView headerEmail;
    String currentFragment = "other";

    ImageView productAdapter;
    DatabaseReference databaseReference;
    List<ShopModel> mShopModel;
    private FirebaseStorage firebaseStorage;
    private ValueEventListener mDBListener;
    SharedPreferences sharedPreferences;
    private ShopModel upload;
    private FirebaseUser firebaseUser;
    private FirebaseAuth firebaseAuth;

    RecyclerView viewHeaderRecycler;
    ImageAdapter imageAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_screen);

        try {
            Toolbar toolbar = findViewById(R.id.toolbar);
            setSupportActionBar(toolbar);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                getWindow().setStatusBarColor(ContextCompat.getColor(this, R.color.colorBlue));
            }

            mDrawerLayout = findViewById(R.id.drawerLayout);
            mDrawerToogle = new ActionBarDrawerToggle(this, mDrawerLayout, toolbar, R.string.open, R.string.close);
            mDrawerLayout.addDrawerListener(mDrawerToogle);
            mDrawerToogle.syncState();

            NavigationView navigationView = findViewById(R.id.nav_view);
            headerEmail = navigationView.getHeaderView(0).findViewById(R.id.header_email);
            navigationView.setNavigationItemSelectedListener(this);

            final Home_Fragment fragment = new Home_Fragment();
            FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
            fragmentTransaction.replace(R.id.frame_layout, fragment, "Home");
            fragmentTransaction.commit();

            firebaseUser = FirebaseAuth.getInstance().getCurrentUser();
            headerEmail.setText(firebaseUser.getEmail());

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem)
    {
        int id = menuItem.getItemId();
        if(id == R.id.home)
        {
            currentFragment = "home";
            Home_Fragment fragment = new Home_Fragment();
            FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
            fragmentTransaction.replace(R.id.frame_layout,fragment,"Home");
            fragmentTransaction.commit();
        }
        else if (id == R.id.myorders)
        {
            currentFragment = "other";
            Myorders_Fragment fragment= new Myorders_Fragment();
            FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
            fragmentTransaction.replace(R.id.frame_layout,fragment,"My Orders");
            fragmentTransaction.commit();
        }

        else if(id == R.id.statistics)
        {
            currentFragment = "other";
            Statistics_Fragment fragment= new Statistics_Fragment();
            FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
            fragmentTransaction.replace(R.id.frame_layout,fragment,"Statistics");
            fragmentTransaction.commit();
        }
        else if(id == R.id.settings)
        {
            currentFragment = "other";
            Settings_Fragment fragment= new Settings_Fragment();
            FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
            fragmentTransaction.replace(R.id.frame_layout,fragment,"Settings");
            fragmentTransaction.commit();
        }
        else if(id == R.id.feedback)
        {
            currentFragment = "other";
            Feedback_Fragment fragment= new Feedback_Fragment();
            FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
            fragmentTransaction.replace(R.id.frame_layout,fragment,"Feedback");
            fragmentTransaction.commit();
        }
        else if(id == R.id.logout)
        {
            currentFragment = "other";
            Logout_Fragment fragment= new Logout_Fragment();
            FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
            fragmentTransaction.replace(R.id.frame_layout,fragment,"Logout");
            fragmentTransaction.commit();
        }
        mDrawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    public void onBackPressed() {
        if(mDrawerLayout.isDrawerOpen(GravityCompat.START))
        {
            mDrawerLayout.closeDrawer(GravityCompat.START);
        }
        else
        {

            if(currentFragment != "home")
            {
                Home_Fragment fragment= new Home_Fragment();
                FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
                fragmentTransaction.replace(R.id.frame_layout,fragment,"Home");
                fragmentTransaction.commit();
            }
            else {
                super.onBackPressed();
            }
        }
    }
}
