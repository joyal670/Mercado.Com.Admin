package com.example.mercadoadmin.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.mercadoadmin.Model.OrderModel;
import com.example.mercadoadmin.Model.ShopModel;
import com.example.mercadoadmin.R;
import com.squareup.picasso.Picasso;

import java.util.List;

public class OrderDataAdapter extends BaseAdapter
{
    Context context;
    List<OrderModel> model;

    public OrderDataAdapter(Context context, List<OrderModel> model) {
        this.context = context;
        this.model = model;
    }

    @Override
    public int getCount() {
        return model.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        convertView = inflater.inflate(R.layout.order_view, null);

        TextView name, number, date;
        name = convertView.findViewById(R.id.order_view_name);
        number = convertView.findViewById(R.id.order_view_number);
        date = convertView.findViewById(R.id.order_view_date);

        name.setText(model.get(position).getContName());
        number.setText(model.get(position).getContNumber());
        date.setText(model.get(position).getOrderDate());

        return convertView;
    }
}