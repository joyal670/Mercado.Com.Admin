package com.example.mercadoadmin.Activity;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentResolver;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.mercadoadmin.Model.ProductModel;
import com.example.mercadoadmin.R;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

public class AddPoduct_Activity extends AppCompatActivity
{

    EditText addproductname, addproductdescription, addproductprice;
    ImageView addproductimage;
    Button addproductupload;
    Spinner addproducttype, addproductstoke;
    private static int image_pic_request = 1;
    private Uri mImageUri;
    private ProgressBar addproductprogress;

    private DatabaseReference mdatabaseReference;
    private StorageReference mstorageReference;
    private FirebaseUser firebaseUser;
    private FirebaseAuth firebaseAuth;
    private StorageTask mUploadTask;
    SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_poduct);

        try {

            addproductname = findViewById(R.id.addproductname);
            addproductdescription = findViewById(R.id.addproductdescription);
            addproducttype = findViewById(R.id.addproducttype);
            addproductprice = findViewById(R.id.addproductprice);
            addproductstoke = findViewById(R.id.addproductstoke);
            addproductimage = findViewById(R.id.addproductimage);
            addproductupload = findViewById(R.id.addproductupload);
            addproductprogress = findViewById(R.id.addproductprogress);

            String[] stoke = {"Out of Stoke", "In Stoke"};
            ArrayAdapter<String> stok = new ArrayAdapter<>(AddPoduct_Activity.this, android.R.layout.simple_spinner_dropdown_item, stoke);
            addproductstoke.setAdapter(stok);

            String[] catogries = {"Supermarket", "Provisionshop", "Stationaryshop", "Fishmarket", "Butchershop", "Vegetableshop", "Medicalshop", "Electronicshop", "Fashion"};
            ArrayAdapter<String> catog = new ArrayAdapter<String>(AddPoduct_Activity.this, android.R.layout.simple_spinner_dropdown_item, catogries);
            addproducttype.setAdapter(catog);

            firebaseAuth = FirebaseAuth.getInstance();
            firebaseUser = firebaseAuth.getCurrentUser();

            sharedPreferences = getSharedPreferences("data", 0);
            String a1 = sharedPreferences.getString("userid", "");


            mdatabaseReference = FirebaseDatabase.getInstance().getReference("shop_owner").child(a1).child("product");
            mstorageReference = FirebaseStorage.getInstance().getReference("shop_owner/shop_product");

            addproductupload.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (mUploadTask != null && mUploadTask.isInProgress()) {
                        Toast.makeText(AddPoduct_Activity.this, "Uploading in Progress", Toast.LENGTH_SHORT).show();
                    } else {
                        uploadFile();
                    }
                }
            });

            addproductimage.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    openFileChooser();
                }
            });

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private String getFileExtention(Uri uri)
    {
        ContentResolver cr = getContentResolver();
        MimeTypeMap mime = MimeTypeMap.getSingleton();
        return mime.getExtensionFromMimeType(cr.getType(uri));
    }

    private void uploadFile()
    {
        try {


            if (mImageUri != null) {
                StorageReference fileRef = mstorageReference.child(System.currentTimeMillis() + "." + getFileExtention(mImageUri));
                mUploadTask = fileRef.putFile(mImageUri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                        Handler handler = new Handler();
                        handler.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                addproductprogress.setProgress(0);
                            }
                        }, 500);

                        Task<Uri> uriTask = taskSnapshot.getStorage().getDownloadUrl();
                        while (!uriTask.isSuccessful()) ;
                        Uri downloadUrl = uriTask.getResult();

                        sharedPreferences = getSharedPreferences("data", 0);
                        String a1 = sharedPreferences.getString("userid", "");

                        ProductModel productModel = new ProductModel(addproductname.getText().toString().trim(), downloadUrl.toString(), addproductdescription.getText().toString(), addproducttype.getSelectedItem().toString(), addproductprice.getText().toString(), addproductstoke.getSelectedItem().toString(), a1);
                        Toast.makeText(AddPoduct_Activity.this, "Success", Toast.LENGTH_SHORT).show();

                        String uploadId = mdatabaseReference.push().getKey();
                        mdatabaseReference.child(uploadId).setValue(productModel);

//                    Intent intent = new Intent(ShopDetails_Activity.this, HomeScreen_Activity.class);
//                    startActivity(intent);

                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(AddPoduct_Activity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }).addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onProgress(@NonNull UploadTask.TaskSnapshot taskSnapshot) {
                        double progress = (100.0 * taskSnapshot.getBytesTransferred() / taskSnapshot.getTotalByteCount());
                        addproductprogress.setProgress((int) progress);
                    }
                });
            } else {
                Toast.makeText(this, "No file Selected", Toast.LENGTH_SHORT).show();
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void openFileChooser() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(intent, image_pic_request);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);

        try {

            if (requestCode == image_pic_request && resultCode == RESULT_OK && data != null && data.getData() != null) {
                mImageUri = data.getData();
                Picasso.get().load(mImageUri).into(addproductimage);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
