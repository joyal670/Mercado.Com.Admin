package com.example.mercadoadmin.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.mercadoadmin.Model.OrderModel;
import com.example.mercadoadmin.Model.totalModel;
import com.example.mercadoadmin.R;
import com.example.mercadoadmin.adapter.StatisticsAdapter;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class ViewDeliverdProducts_Activity extends AppCompatActivity {

    ListView statisticslistview;
    SharedPreferences sharedPreferences;
    List<OrderModel> mOrderModel;
    totalModel mtotalModel;
    DatabaseReference databaseReference;
    StatisticsAdapter mStatisticsAdapter;
    String status = "2";
    TextView totalorders, totalprice;
    int total = 0;
    String a1;
    int cout = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_deliverd_products);

        try {

            statisticslistview = findViewById(R.id.statisticslistview);
            totalorders = findViewById(R.id.totalorders);
            totalprice = findViewById(R.id.totalprice);

            sharedPreferences = getSharedPreferences("data", 0);
            a1 = sharedPreferences.getString("userid", "");

            databaseReference = FirebaseDatabase.getInstance().getReference("order_data");
            databaseReference.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    mOrderModel.clear();
                    for (DataSnapshot dataSnapshot1 : dataSnapshot.getChildren()) {
                        if (a1.equals(dataSnapshot1.child("shopownerId").getValue().toString())) {
                            if (status.equals(dataSnapshot1.child("status").getValue().toString())) {
                                try {

                                    int qty = 0;
                                    int price = 0;

                                    qty = qty + Integer.parseInt(dataSnapshot1.child("productQty").getValue().toString());
                                    price = price + Integer.parseInt(dataSnapshot1.child("productPrice").getValue().toString());
                                    int temp = qty * price;
                                    total = total + temp;
                                    totalprice.setText(total + "");

                                    cout = cout + 1;
                                    totalorders.setText(cout + "");

                                } catch (NumberFormatException e) {
                                    e.printStackTrace();
                                }

                                OrderModel upload = dataSnapshot1.getValue(OrderModel.class);
                                mOrderModel.add(upload);
                            }

                        }
                    }
                    mStatisticsAdapter.notifyDataSetChanged();

                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    Toast.makeText(ViewDeliverdProducts_Activity.this, databaseError.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });
            mOrderModel = new ArrayList<>();
            mStatisticsAdapter = new StatisticsAdapter(ViewDeliverdProducts_Activity.this, mOrderModel);
            statisticslistview.setAdapter(mStatisticsAdapter);


        } catch (Exception e) {
            e.printStackTrace();
        }
//        StoreData();
    }

    private void StoreData()
    {
        DatabaseReference reference =  FirebaseDatabase.getInstance().getReference("shop_owner").child(a1).child("total");
        mtotalModel = new totalModel();
        String date = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());
        mtotalModel.setDate(date);
        mtotalModel.setTotal(String.valueOf(total));

        String key = reference.push().getKey();
        reference.child(key).setValue(mtotalModel);
    }
}
