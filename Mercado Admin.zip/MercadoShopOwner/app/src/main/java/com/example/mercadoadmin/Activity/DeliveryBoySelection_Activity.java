package com.example.mercadoadmin.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.BitmapFactory;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.mercadoadmin.Fragments.Myorders_Fragment;
import com.example.mercadoadmin.Model.OrderModel;
import com.example.mercadoadmin.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

public class DeliveryBoySelection_Activity extends AppCompatActivity
{
    String chkImageUrl, chkName, chkDescription, chkPrice, chkType, chkStoke, chkpUserkey, chkmKey, UserKey, chkqty;
    String house, area, city, district, pincode, contName, contNumber, contAltNumber, totalPrice, status, deliveryboy, orderid;

    ImageView current_image;
    TextView current_name, current_price, current_qty, current_house, current_area, current_pincode, current_cname, current_cnumber, current_status;
    Spinner current_deliveryboy;
    Button current_button;

    DatabaseReference databaseReference;
    List<String> spinnerData = new ArrayList<String>();
    ValueEventListener listener;
    ArrayAdapter<String> adapter;
    ArrayList<String> spinnerDatalist;
    String msg = "Select --  ";
    OrderModel orderModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delivery_boy_selection);

        try {

            chkImageUrl = getIntent().getExtras().getString("chkImageUrl");
            chkName = getIntent().getExtras().getString("chkName");
            chkDescription = getIntent().getExtras().getString("chkDescription");
            chkPrice = getIntent().getExtras().getString("chkPrice");
            chkType = getIntent().getExtras().getString("chkType");
            chkStoke = getIntent().getExtras().getString("chkStoke");
            chkpUserkey = getIntent().getExtras().getString("chkpUserkey");
            chkmKey = getIntent().getExtras().getString("chkmKey");
            UserKey = getIntent().getExtras().getString("UserKey");
            chkqty = getIntent().getExtras().getString("chkqty");

            house = getIntent().getExtras().getString("house");
            area = getIntent().getExtras().getString("area");
            city = getIntent().getExtras().getString("city");
            district = getIntent().getExtras().getString("district");
            pincode = getIntent().getExtras().getString("pincode");
            contName = getIntent().getExtras().getString("contName");
            contNumber = getIntent().getExtras().getString("contNumber");
            contAltNumber = getIntent().getExtras().getString("contAltNumber");
            totalPrice = getIntent().getExtras().getString("totalPrice");
            status = getIntent().getExtras().getString("status");
            orderid = getIntent().getExtras().getString("orderId");

            current_image = findViewById(R.id.current_image);
            current_name = findViewById(R.id.current_name);
            current_price = findViewById(R.id.current_price);
            current_qty = findViewById(R.id.current_qty);
            current_house = findViewById(R.id.current_house);
            current_area = findViewById(R.id.current_area);
            current_pincode = findViewById(R.id.current_pincode);
            current_cname = findViewById(R.id.current_cname);
            current_cnumber = findViewById(R.id.current_cnumber);
            current_deliveryboy = findViewById(R.id.current_deliveryboy);
            current_button = findViewById(R.id.current_button);
            current_status = findViewById(R.id.current_status);

            Picasso.get().load(chkImageUrl).into(current_image);
            current_name.setText(chkName);
            current_price.setText(chkPrice);
            current_qty.setText(chkqty);
            current_house.setText(house);
            current_area.setText(area);
            current_pincode.setText(pincode);
            current_cname.setText(contName);
            current_cnumber.setText(contNumber);

            if (status.equals("0")) {
                current_status.setText("Pending, Not yet Deliverd");
            } else if (status.equals("1")) {
                current_status.setText("Order is Picked up by the Delivery Agent");
                current_button.setEnabled(false);
            } else if (status.equals("2")) {
                current_status.setText("Deliverd");
                current_button.setEnabled(false);
            } else {
                current_status.setText("Cancelled");
                current_button.setEnabled(false);
            }


            databaseReference = FirebaseDatabase.getInstance().getReference("delivery_boy");

            spinnerDatalist = new ArrayList<>();
            adapter = new ArrayAdapter<String>(DeliveryBoySelection_Activity.this, android.R.layout.simple_spinner_dropdown_item, spinnerDatalist);

            listener = databaseReference.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    spinnerDatalist.clear();
                    spinnerDatalist.add(msg);
                    for (DataSnapshot dataSnapshot1 : dataSnapshot.getChildren()) {
                        String temp = dataSnapshot1.getKey();
                        if (temp.equalsIgnoreCase("order_data")) {

                        } else {
                            spinnerDatalist.add(dataSnapshot1.getKey().toString());
                            current_deliveryboy.setAdapter(adapter);
                        }

                    }
                    adapter.notifyDataSetChanged();
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    Toast.makeText(DeliveryBoySelection_Activity.this, databaseError.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });
            current_deliveryboy.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });

            current_button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (current_deliveryboy.getSelectedItem().toString().equalsIgnoreCase(msg)) {
                        Toast.makeText(DeliveryBoySelection_Activity.this, "Select ID", Toast.LENGTH_SHORT).show();
                    } else {
                        updateStatus();
                    }

                }
            });

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void updateStatus()
    {
        try {


            SharedPreferences sharedPreferences;
            sharedPreferences = getSharedPreferences("data", 0);
            final String a1 = sharedPreferences.getString("userid", "");

            final DatabaseReference reference = FirebaseDatabase.getInstance().getReference("order_data").child(orderid);
            reference.child("status").setValue("1");
            reference.child("deliveryBoyId").setValue(current_deliveryboy.getSelectedItem().toString());

            NotificationCompat.Builder builder = new NotificationCompat.Builder(this)
                    .setSmallIcon(R.drawable.ic_launcher_background)
                    .setLargeIcon(BitmapFactory.decodeResource(getResources(), R.drawable.ic_launcher_background))
                    .setContentTitle("New Order")
                    .setContentText("Order is picked up by the delivery agent")
                    .setAutoCancel(true)
                    .setDefaults(NotificationCompat.DEFAULT_ALL);

            Uri path = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            builder.setSound(path);

            NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                String channelId = "Your_Channel_ID";
                NotificationChannel channel = new NotificationChannel(channelId, "Chanel Human redable Text", NotificationManager.IMPORTANCE_DEFAULT);
                notificationManager.createNotificationChannel(channel);
                builder.setChannelId(channelId);
            }
            notificationManager.notify(1, builder.build());

            Toast.makeText(DeliveryBoySelection_Activity.this, "Status Updated", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(DeliveryBoySelection_Activity.this, HomeScreen_Activity.class);
            startActivity(intent);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
//    private void updateUserStatus()
//    {
//        final DatabaseReference referenceUser;
//
//        referenceUser = FirebaseDatabase.getInstance().getReference("user_data").child(UserKey).child("order_data");
//        referenceUser.addValueEventListener(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot dataSnapshot)
//            {
//                for(DataSnapshot dataSnapshot1 : dataSnapshot.getChildren())
//                {
//                    String name = dataSnapshot1.child("chkName").getValue().toString();
//                    String price = dataSnapshot1.child("chkPrice").getValue().toString();
//                    String qty = dataSnapshot1.child("chkqty").getValue().toString();
//                    String num = dataSnapshot1.child("contName").getValue().toString();
//                    String cnum = dataSnapshot1.child("contNumber").getValue().toString();
//                    String mkey = dataSnapshot1.child("chkmKey").getValue().toString();
//                    String ukey = dataSnapshot1.child("userKey").getValue().toString();
//
//                    if(chkName.equals(name) && chkPrice.equals(price) && chkqty.equals(qty) && contName.equals(num) && contNumber.equals(cnum) && chkmKey.equals(mkey) && UserKey.equals(ukey))
//                    {
//                        String pushkey = dataSnapshot1.getKey();
//                        referenceUser.child(pushkey).child("status").setValue("1");
//                    }
//                }
//            }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError databaseError)
//            {
//                Toast.makeText(DeliveryBoySelection_Activity.this, databaseError.getMessage(), Toast.LENGTH_SHORT).show();
//            }
//        });
//
//    }


}
