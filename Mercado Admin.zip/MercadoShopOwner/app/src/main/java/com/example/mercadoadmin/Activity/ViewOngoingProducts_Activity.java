package com.example.mercadoadmin.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.mercadoadmin.Model.OrderModel;
import com.example.mercadoadmin.R;
import com.example.mercadoadmin.adapter.StatisticsAdapter;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class ViewOngoingProducts_Activity extends AppCompatActivity {

    ListView ongoinglistview;
    SharedPreferences sharedPreferences;
    List<OrderModel> mOrderModel;
    DatabaseReference databaseReference;
    StatisticsAdapter mStatisticsAdapter;
    String status = "1";

    TextView totalorders, totalprice;
    int total = 0;
    int count = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_ongoing_products);

        try {

            ongoinglistview = findViewById(R.id.ongoinglistview);
            totalorders = findViewById(R.id.totalorders1);
            totalprice = findViewById(R.id.totalprice1);

            sharedPreferences = getSharedPreferences("data", 0);
            final String a1 = sharedPreferences.getString("userid", "");

            databaseReference = FirebaseDatabase.getInstance().getReference("order_data");
            databaseReference.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    mOrderModel.clear();
                    for (DataSnapshot dataSnapshot1 : dataSnapshot.getChildren()) {
                        if (a1.equals(dataSnapshot1.child("shopownerId").getValue().toString())) {
                            if (status.equals(dataSnapshot1.child("status").getValue().toString())) {
                                try {

                                    int qty = 0;
                                    int price = 0;

                                    qty = qty + Integer.parseInt(dataSnapshot1.child("productQty").getValue().toString());
                                    price = price + Integer.parseInt(dataSnapshot1.child("productPrice").getValue().toString());
                                    int temp = qty * price;
                                    total = total + temp;
                                    totalprice.setText(total + "");

                                    count = count + 1;
                                    totalorders.setText(count + "");

                                } catch (NumberFormatException e) {
                                    e.printStackTrace();
                                }
                                OrderModel upload = dataSnapshot1.getValue(OrderModel.class);
                                mOrderModel.add(upload);
                            }

                        }
                    }
                    mStatisticsAdapter.notifyDataSetChanged();
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    Toast.makeText(ViewOngoingProducts_Activity.this, databaseError.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });

            mOrderModel = new ArrayList<>();
            mStatisticsAdapter = new StatisticsAdapter(ViewOngoingProducts_Activity.this, mOrderModel);
            ongoinglistview.setAdapter(mStatisticsAdapter);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
