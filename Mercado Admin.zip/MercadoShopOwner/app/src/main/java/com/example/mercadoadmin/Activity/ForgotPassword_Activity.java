package com.example.mercadoadmin.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.example.mercadoadmin.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.SignInMethodQueryResult;

public class ForgotPassword_Activity extends AppCompatActivity {

    private EditText forgotemailaddress;
    private Button forgotbtn;
    private ProgressBar forgotprogressBar;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);

        forgotemailaddress = findViewById(R.id.forgotemailaddress);
        forgotbtn = findViewById(R.id.forgotbtn);
        forgotprogressBar = findViewById(R.id.forgotprogressBar);

        mAuth = FirebaseAuth.getInstance();

        forgotbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                forgotPassword();
            }
        });
    }

    private void forgotPassword() {
        try {
            forgotprogressBar.setVisibility(View.VISIBLE);
            mAuth.fetchSignInMethodsForEmail(forgotemailaddress.getText().toString()).addOnCompleteListener(new OnCompleteListener<SignInMethodQueryResult>() {
                @Override
                public void onComplete(@NonNull Task<SignInMethodQueryResult> task) {
                    if (task.getResult().getSignInMethods().isEmpty()) {
                        forgotprogressBar.setVisibility(View.GONE);
                        Toast.makeText(ForgotPassword_Activity.this, "Not an Registerd Email Address", Toast.LENGTH_SHORT).show();
                    } else {
                        mAuth.sendPasswordResetEmail(forgotemailaddress.getText().toString()).addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                if (task.isSuccessful()) {
                                    Toast.makeText(ForgotPassword_Activity.this, "An Email has benn sent", Toast.LENGTH_SHORT).show();
                                } else {
                                    Toast.makeText(ForgotPassword_Activity.this, task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
                    }
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
