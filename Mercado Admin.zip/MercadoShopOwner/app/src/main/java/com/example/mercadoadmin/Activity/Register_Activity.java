package com.example.mercadoadmin.Activity;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.example.mercadoadmin.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.Objects;

public class Register_Activity extends AppCompatActivity {

    private EditText registerusername, registeremailaddress, registerpassword;
    private Button registerbtn;
    private ProgressBar registerprogressBar;
    private FirebaseAuth firebaseAuth;
    private DatabaseReference databaseReference;
    SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        registerusername = findViewById(R.id.registerusername);
        registeremailaddress = findViewById(R.id.registeremailaddress);
        registerpassword = findViewById(R.id.registerpassword);
        registerbtn = findViewById(R.id.registerbtn);
        registerprogressBar = findViewById(R.id.registerprogressBar);

        firebaseAuth = FirebaseAuth.getInstance();

        registerbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String username = registerusername.getText().toString();
                final String emailaddress = registeremailaddress.getText().toString();
                final String password = registerpassword.getText().toString();

                if(username.isEmpty() || emailaddress.isEmpty() || password.isEmpty())
                {
                    Toast.makeText(Register_Activity.this, "All Fileds are Required", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    register(username,emailaddress,password);
                }
            }
        });

    }
    private void register(final String username, final String emailaddress, String password)
    {
        registerprogressBar.setVisibility(View.VISIBLE);
        firebaseAuth.createUserWithEmailAndPassword(emailaddress, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @RequiresApi(api = Build.VERSION_CODES.KITKAT)
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful())
                {
                    FirebaseUser rUser = firebaseAuth.getCurrentUser();
                    String userId = rUser.getUid();

                    sharedPreferences = getSharedPreferences("data",0);
                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putString("userid", userId);
                    editor.putBoolean("login_status",true);
                    editor.apply();

                    databaseReference = FirebaseDatabase.getInstance().getReference("shop_owner").child(userId);
                    HashMap<String,String> hashMap = new HashMap<>();
                    hashMap.put("userId", userId);
                    hashMap.put("userName", username);
                    hashMap.put("userEmail", emailaddress);
                    databaseReference.setValue(hashMap).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @RequiresApi(api = Build.VERSION_CODES.KITKAT)
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if(task.isSuccessful())
                            {
                                Intent intent = new Intent(Register_Activity.this, ShopDetails_Activity.class);
                                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                                startActivity(intent);
                            }
                            else
                            {
                                Toast.makeText(Register_Activity.this, Objects.requireNonNull(task.getException()).getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        }
                    });

                }
                else
                {
                    registerprogressBar.setVisibility(View.GONE);
                    Toast.makeText(Register_Activity.this, Objects.requireNonNull(task.getException()).getMessage(), Toast.LENGTH_SHORT).show();

                }
            }
        });
    }
}
