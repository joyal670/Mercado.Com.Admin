package com.example.mercadoadmin.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Toast;

import com.example.mercadoadmin.Model.ShopModel;
import com.example.mercadoadmin.R;
import com.example.mercadoadmin.adapter.ImageAdapter;
import com.example.mercadoadmin.adapter.ProductAdapter;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;

import java.util.ArrayList;
import java.util.List;

public class ViewShopDetails_Activity extends AppCompatActivity implements ImageAdapter.OnitemClickListener {


    RecyclerView viewshopdetailsrecycler;
    ImageAdapter shopAdapter;
    DatabaseReference databaseReference;
    List<ShopModel> mShopmodel;
    private FirebaseStorage firebaseStorage;
    private ValueEventListener mDBListener;
    SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_shop_details);

        try {

            viewshopdetailsrecycler = findViewById(R.id.viewshopdetailsrecycler);
            viewshopdetailsrecycler.setLayoutManager(new LinearLayoutManager(this));
            viewshopdetailsrecycler.setHasFixedSize(true);

            firebaseStorage = FirebaseStorage.getInstance();
            sharedPreferences = getSharedPreferences("data", 0);
            String a1 = sharedPreferences.getString("userid", "");

            Query query = FirebaseDatabase.getInstance().getReference("shop_owner").child(a1).child("shop_details");

            query.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    mShopmodel.clear();
                    for (DataSnapshot dataSnapshot1 : dataSnapshot.getChildren()) {
                        ShopModel upload = dataSnapshot1.getValue(ShopModel.class);
//                    upload.set(dataSnapshot1.getKey());
                        mShopmodel.add(upload);
                    }
                    shopAdapter.notifyDataSetChanged();
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    Toast.makeText(ViewShopDetails_Activity.this, databaseError.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });

            mShopmodel = new ArrayList<>();
            shopAdapter = new ImageAdapter(ViewShopDetails_Activity.this, mShopmodel);
            viewshopdetailsrecycler.setAdapter(shopAdapter);
            shopAdapter.setOnClickListener(ViewShopDetails_Activity.this);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onItemClick(int position) {
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        try {
            databaseReference.removeEventListener(mDBListener);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
