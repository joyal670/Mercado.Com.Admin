package com.example.mercadoadmin.Model;

public class totalModel {
    private String date;
    private String total;

    public totalModel(){}

    public totalModel(String date, String total) {
        this.date = date;
        this.total = total;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTotal() {
        return total;
    }

    public void setTotal(String total) {
        this.total = total;
    }
}
