package com.example.mercadoadmin.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.mercadoadmin.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class Login_Activity extends AppCompatActivity {

    private EditText loginemailaddres, loginpassword;
    private Button loginbtn;
    private TextView loginforgotpassword;
    private ProgressBar loginprogressBar;
    private FirebaseAuth firebaseAuth;
    SharedPreferences sharedPreferences;
    FirebaseUser firebaseUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        try {

            firebaseAuth = FirebaseAuth.getInstance();
            firebaseUser = firebaseAuth.getCurrentUser();

            loginemailaddres = findViewById(R.id.loginemailaddres);
            loginpassword = findViewById(R.id.loginpassword);
            loginbtn = findViewById(R.id.loginbtn);
            loginforgotpassword = findViewById(R.id.loginforgotpassword);
            loginprogressBar = findViewById(R.id.loginprogressBar);
            firebaseAuth = FirebaseAuth.getInstance();

            loginforgotpassword.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent i = new Intent(Login_Activity.this, ForgotPassword_Activity.class);
                    startActivity(i);
                }
            });


            loginbtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String email = loginemailaddres.getText().toString();
                    String password = loginpassword.getText().toString();
                    if (email.isEmpty() || password.isEmpty()) {
                        Toast.makeText(Login_Activity.this, "All fireds are Required", Toast.LENGTH_SHORT).show();
                    } else {
                        login(email, password);
                    }
                }
            });

            loginforgotpassword.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(Login_Activity.this, ForgotPassword_Activity.class);
                    startActivity(intent);
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void login(String email, String password)
    {
        try {

            loginprogressBar.setVisibility(View.VISIBLE);
            firebaseAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    loginprogressBar.setVisibility(View.GONE);
                    if (task.isSuccessful()) {
                        sharedPreferences = getSharedPreferences("data", 0);
                        SharedPreferences.Editor editor = sharedPreferences.edit();
                        editor.putString("userid", task.getResult().getUser().getUid());
                        editor.putBoolean("login_status", true);
                        editor.apply();


                        Intent intent = new Intent(Login_Activity.this, HomeScreen_Activity.class);
                        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(intent);
                        finish();
                    } else {
                        Toast.makeText(Login_Activity.this, task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();

        try {
            SharedPreferences sharedPreferences = getSharedPreferences("data", 0);
            boolean logg = sharedPreferences.getBoolean("login_status", false);
            if (logg == true) {
                Intent intent = new Intent(Login_Activity.this, HomeScreen_Activity.class);
                startActivity(intent);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
