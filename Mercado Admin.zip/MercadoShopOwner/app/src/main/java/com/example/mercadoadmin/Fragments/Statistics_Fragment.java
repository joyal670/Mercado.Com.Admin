package com.example.mercadoadmin.Fragments;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import com.example.mercadoadmin.Activity.SortData_Activity;
import com.example.mercadoadmin.Activity.ViewDeliverdProducts_Activity;
import com.example.mercadoadmin.Activity.ViewOngoingProducts_Activity;
import com.example.mercadoadmin.Model.OrderModel;
import com.example.mercadoadmin.R;
import com.example.mercadoadmin.adapter.OrderDataAdapter;
import com.example.mercadoadmin.adapter.StatisticsAdapter;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 */
public class Statistics_Fragment extends Fragment
{
    DatabaseReference databaseReference;
    SharedPreferences sharedPreferences;
    List<OrderModel> mOrderModel;
    StatisticsAdapter mStatisticsAdapter;
    Button view_deliverd_products, view_ongoing, filterdata;

    public Statistics_Fragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_statistics, container, false);

        sharedPreferences = this.getActivity().getSharedPreferences("data",0);
        final String a1 = sharedPreferences.getString("userid","");


        view_deliverd_products = view.findViewById(R.id.view_deliverd_products);
        view_ongoing = view.findViewById(R.id.view_ongoing);
        filterdata = view.findViewById(R.id.filterdata);

        view_deliverd_products.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getContext(), ViewDeliverdProducts_Activity.class);
                startActivity(intent);
            }
        });

        view_ongoing.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getContext(), ViewOngoingProducts_Activity.class);
                startActivity(intent);
            }
        });

        filterdata.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getContext(), SortData_Activity.class);
                startActivity(intent);
            }
        });

        return view;
    }
}
